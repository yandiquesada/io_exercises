//
//  ProductViewModel.swift
//  productlist
//
//  Created by Yandi Alonso on 4/4/21.
//

import Foundation

class ProductViewModel {
    private let productRepository = ProductRepository()
    var productData: ProductData?
    var selectedProductIndex = -1
    
    // TODO: improve to fetch products only once, we now the file will never change
    func loadProducts() {
        productData = productRepository.getProducts()
    }
    
    // TODO: implement method to load products ordered by model number
    
    // TODO: get product info by position
    func getProduct(productIndex: Int) -> Product? {
        guard let productData = productData, productIndex > -1 else {return nil}
        return productData.products[productIndex]
    }
}
