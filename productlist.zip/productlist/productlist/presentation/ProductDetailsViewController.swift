//
//  ProductDetailsViewController.swift
//  productlist
//
//  Created by Yandi Alonso on 4/4/21.
//

import UIKit
import Kingfisher

class ProductDetailsViewController: UIViewController {
    
    @IBOutlet var productImage: UIImageView!
    @IBOutlet var productTitle: UILabel!
    
    var productViewModel: ProductViewModel?
    var product: Product?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadProduct()
        setUpViews()
    }
    
    private func loadProduct() {
        // TODO: add code here!
    }
    
    private func setUpViews() {
        // TODO: add code here!
    }
    
}

