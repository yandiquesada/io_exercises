//
//  ProductListViewController.swift
//  productlist
//
//  Created by Yandi Alonso on 4/3/21.
//

import UIKit

class ProductListViewController: UIViewController {
    
    @IBOutlet var productListTableView: UITableView!
    
    private let productViewModel = ProductViewModel()
    private let rowHeight:CGFloat = 80.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // TODO: load product data
        loadProductData()
        setUpViews()
    }
    
    private func loadProductData() {
        productViewModel.loadProducts()
    }
    
    private func setUpViews() {
        setUpProductListTableView()
    }
    
    private func setUpProductListTableView() {
        productListTableView.register(UITableViewCell.self, forCellReuseIdentifier: "forCellReuseIdentifier")
        productListTableView.estimatedRowHeight = rowHeight
        // productListTableView.separatorStyle = .none
        productListTableView.delegate = self
        productListTableView.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        // TODO: pass viewModel to productDetailsViewController
        if let productDetailsViewController = segue.destination as? ProductDetailsViewController {
            productDetailsViewController.productViewModel = productViewModel
        }
    }
}

extension ProductListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let tableViewCell: UITableViewCell = self.productListTableView.dequeueReusableCell(withIdentifier: "forCellReuseIdentifier") else {
            return UITableViewCell()
        }
        
        guard let product = productViewModel.productData?.products[indexPath.row] else {
            return UITableViewCell()
        }
        
        tableViewCell.textLabel?.text = product.title
        
        return tableViewCell
    }
        
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // self.productViewModel.selectedProductIndex = indexPath.row
    }
}
