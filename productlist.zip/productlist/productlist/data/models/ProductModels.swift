//
//  ProductModels.swift
//  productlist
//
//  Created by Yandi Alonso on 4/3/21.
//

import Foundation

struct Product: Codable {
    let title: String
    let mpn: String
    let imageUrl: String
    let inventory: Int
}

struct ProductData: Codable {
    let numFound: Int
    let products: [Product]
}

struct ProductResponse: Codable {
    let data: ProductData
}

