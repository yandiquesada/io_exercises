//
//  ProductRepository.swift
//  productlist
//
//  Created by Yandi Alonso on 4/3/21.
//

import Foundation

class ProductRepository {
    private let productLocalDataSource = ProductLocalDataSource()
    //TODO: implement support for remote data source
    
    //TODO: avoid read all the time if we are using local dataSource    
    func getProducts() -> ProductData? {
        return productLocalDataSource.getProducts()
    }
}
