//
//  ProductLocalDataSource.swift
//  productlist
//
//  Created by Yandi Alonso on 4/3/21.
//

import Foundation

class ProductLocalDataSource {
    func getProducts() -> ProductData? {
        if let jsonproductData = readProductDataFile() {
            guard let productResponse = parseProductData(jsonProductData: jsonproductData) else {
                return nil
            }
            return productResponse.data
        }
        return nil
    }
    
    
    private func readProductDataFile() -> Data? {
        do {
            if let filePath = Bundle.main.path(forResource: "product_list", ofType:"json"),
               let jsonData = try String(contentsOfFile: filePath).data(using: .utf8) {
                return jsonData
            }
        }
        catch {
            print(error)
        }
        return nil
    }

    private func parseProductData(jsonProductData: Data) -> ProductResponse? {
        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let productResponse = try decoder.decode(ProductResponse.self, from: jsonProductData)
            return productResponse
        }
        catch {
            print(error)
            return nil
        }
    }
}
